// Code developed by Nikhil Challa as part of ML in IOT Course - year : 2022
// Team members : Simon Erlandsson
// To get full understanding of the code, please refer to below document in git
// https://github.com/niil87/Machine-Learning-for-IOT---Fall-2022-Batch-Lund-University/blob/main/Math_for_Understanding_Deep_Neural_Networks.pdf
// The equations that corresponds to specific code will be listed in the comments next to code

#define fRAND ( rand()*1.0/RAND_MAX-0.5 )*2   // random number generator between -1 and +1 
#define ACT(a) max(a,0)    // RELU(a)


#ifdef DATA_TYPE_FLOAT 
  #define DATA_TYPE float
  #define EXP_LIMIT 78.0  // limit 88.xx but we need to factor in accumulation for softmax
  #define EXP(a) expl(a)
#else
  #define DATA_TYPE double
  #define EXP_LIMIT 699.0 // limit is 709.xx but we need to factor in accumulation for softmax
  #define EXP(a) exp(a)
#endif

#define IN_VEC_SIZE first_layer_input_cnt
#define OUT_VEC_SIZE classes_cnt

// size of different vectors
size_t numTestData = test_data_cnt;
size_t numValData = validation_data_cnt;
size_t numTrainData = train_data_cnt;


size_t numLayers = sizeof(NN_def) / sizeof(NN_def[0]);
// size of the input to NN


// dummy input for testing
DATA_TYPE input[IN_VEC_SIZE];

// dummy output for testing
DATA_TYPE hat_y[OUT_VEC_SIZE];    // target output
DATA_TYPE y[OUT_VEC_SIZE];        // output after forward propagation


// creating array index to randomnize order of training data
int indxArray[train_data_cnt];

// Convention: Refer to 
typedef struct neuron_t {
	int numInput;
	DATA_TYPE* W;
	DATA_TYPE B;
	DATA_TYPE X;

	// For back propagation, convention, dA means dL/dA or partial derivative of Loss over Accumulative output
	DATA_TYPE* dW;
	DATA_TYPE dA;
	DATA_TYPE dB;

} neuron;

typedef struct layer_t {
	int numNeuron;
	neuron* Neu;
} layer;

// initializing the layer as global parameter
layer* L = NULL;

// Weights written to here will be sent/received via bluetooth. 
DATA_TYPE* WeightBiasPtr = NULL;

// Equation (8)
DATA_TYPE AccFunction (unsigned int layerIndx, int nodeIndx) {
	DATA_TYPE A = 0;

	for (int k = 0; k < NN_def[layerIndx - 1]; k++) {

	// updating weights/bais and resetting gradient value if non-zero
	if (L[layerIndx].Neu[nodeIndx].dW[k] != 0.0 ) {
		L[layerIndx].Neu[nodeIndx].W[k] += L[layerIndx].Neu[nodeIndx].dW[k];
		L[layerIndx].Neu[nodeIndx].dW[k] = 0.0;
	}

	A += L[layerIndx].Neu[nodeIndx].W[k] * L[layerIndx - 1].Neu[k].X;

	}

	if (L[layerIndx].Neu[nodeIndx].dB != 0.0 ) {
		L[layerIndx].Neu[nodeIndx].B += L[layerIndx].Neu[nodeIndx].dB;
		L[layerIndx].Neu[nodeIndx].dB = 0.0;
	}
	A += L[layerIndx].Neu[nodeIndx].B;

	return A;
}


// NEED HANDLING TO ENSURE NO WEIGHTS AND BIAS ARE CREATED FOR FIRST LAYER OR THROW ERROR IF ACCESSED ACCIDENTLY
// EVEN THOUGH WE HAVENT EXPLICITLY CALLED CREATED THE NEURON FOR FIRST LAYER, HOW WAS L[i].Neu[j].X SUCCESSFUL IN FORWARD PROPAGATION!!
neuron createNeuron(int numInput) {

	neuron N1;

	N1.B = fRAND;
	N1.numInput = numInput;
	N1.W = (DATA_TYPE*)calloc(numInput, sizeof(DATA_TYPE));
	N1.dW = (DATA_TYPE*)calloc(numInput, sizeof(DATA_TYPE));
	// initializing values of W to rand and dW to 0
	//int Sum = 0;
	for (int i = 0; i < numInput; i++) {
		N1.W[i] = fRAND;
		N1.dW[i] = 0.0;
	}
	N1.dA = 0.0;
	N1.dB = 0.0;

	return N1;

}

layer createLayer (int numNeuron) {
	layer L1;
	L1.numNeuron = numNeuron;
	L1.Neu = (neuron*)calloc(numNeuron, sizeof(neuron));
	return L1;
}

void createNetwork() {

	L = (layer*)calloc(numLayers, sizeof(layer));

	// First layer has no input weights
	L[0] = createLayer(NN_def[0]);

	for (unsigned int i = 1; i < numLayers; i++) {
		L[i] = createLayer(NN_def[i]);
		for (unsigned int j = 0; j < NN_def[i]; j++) {
			L[i].Neu[j] = createNeuron(NN_def[i - 1]);
		}
	}

	// creating indx array for shuffle function to be used later
	for (unsigned int i = 0; i <  numTrainData; i ++ ) {
		indxArray[i] = i;
	}

}

float l2_penalty;
// this function is to calculate dA
DATA_TYPE dLossCalc(unsigned int layerIndx, unsigned int nodeIndx) {

  DATA_TYPE Sum = 0;
  // int outputSize = NN_def[numLayers - 1];
  // for the last layer, we use complex computation
  if (layerIndx == numLayers - 1) {
    Sum = y[nodeIndx] - hat_y[nodeIndx]; // Equation (17)
    // Incorporate L2 regularization effect in the derivative calculation for
    // the last layer
    const double lambda = 0; // Regularization strength
    for (int k = 0; k < NN_def[layerIndx - 1]; k++) {
      double weight = L[layerIndx].Neu[nodeIndx].W[k];
      // Sum += lambda * weight; // Adjusting Sum to include the derivative of
      // the L2 regularization term
      l2_penalty += weight * weight; // Sum of squared weights
    }
    l2_penalty *= lambda / 2.0; // L2 penalty term
    Sum += l2_penalty;          // Adding L2 penalty to thec loss
    // for all except last layer, we use simple aggregate of dA
  } else if (AccFunction(layerIndx, nodeIndx) > 0) {
    for (unsigned int i = 0; i < NN_def[layerIndx + 1]; i++) {
      Sum += L[layerIndx + 1].Neu[i].dA *
             L[layerIndx + 1].Neu[i].W[nodeIndx]; // Equation (24)
    }
  } else { // refer to "Neat Trick" and Equation (21)
    Sum = 0;
  }

  return Sum;
}

// void forwardProp() {
	
// 	DATA_TYPE Fsum = 0;
// 	int maxIndx = 0;
// 	// Propagating through network
// 	for (unsigned int i = 0; i < numLayers; i++) {
// 		// assigning node values straight from input for first layer
// 		if (i == 0) {
// 			for (unsigned int j = 0; j < NN_def[0];j++) {
// 				L[i].Neu[j].X = input[j];
// 			}
// 		} else if (i == numLayers - 1) {
//       // softmax functionality but require normalizing performed later
// 			for (unsigned int j = 0; j < NN_def[i];j++) {
// 				y[j] = AccFunction(i,j);
// 				// tracking the max index
// 				if ( ( j > 0 ) && (abs(y[maxIndx]) < abs(y[j])) ) {
// 					maxIndx = j;
// 				}
// 			}
// 		} else {	
// 			// for subsequent layers, we need to perform RELU
// 			for (unsigned int j = 0; j < NN_def[i];j++) {
// 				L[i].Neu[j].X = ACT(AccFunction(i,j));				// Equation (21)	
// 			}	
// 		}
// 	}

//   // performing exp but ensuring we dont exceed 709 or 88 in any terms 
// 	DATA_TYPE norm = abs(y[maxIndx]);
// 	if (norm > EXP_LIMIT) {
// #if DEBUG
// 		Serial.print("Max limit exceeded for exp:");
// 		Serial.println(norm);
// #endif
// 		norm = norm / EXP_LIMIT;
// #if DEBUG
// 		Serial.print("New divising factor:");
// 		Serial.println(norm);
// #endif
// 	} else {
// 		norm = 1.0;
// 	}
// 	for (unsigned int j = 0; j < NN_def[numLayers-1];j++) {
// 		// int flag = 0;
// 		y[j] = EXP(y[j]/norm);
// 		Fsum += y[j];
// 	}

//   // final normalizing for softmax
// 	for (unsigned int j = 0; j < NN_def[numLayers-1];j++) {
// 		y[j] = y[j]/Fsum;
// 	}
// }


void applyDropout(neuron *neurons, unsigned int numNeurons,
                  double dropoutRate) {
  for (unsigned int i = 0; i < numNeurons; i++) {

    int dropoutMask = ((double)rand() / RAND_MAX) < dropoutRate ? 0 : 1;

    // Apply the dropout mask to the neuron's activation
    neurons[i].X *= dropoutMask;
    // if ((double)rand() / RAND_MAX < dropoutRate) {
    // neurons[i].X = 0; // Setting activation to zero with a probability of
    // dropoutRate
    //}
  }
}

void forwardProp(int isTraining) {

  DATA_TYPE Fsum = 0;
  int maxIndx = 0;
  double dropoutRate = 0.2;
  // Propagating through network
  for (unsigned int i = 0; i < numLayers; i++) {
    // assigning node values straight from input for first layer
    if (i == 0) {
      for (unsigned int j = 0; j < NN_def[0]; j++) {
        L[i].Neu[j].X = input[j];
      }
    } else if (i == numLayers - 1) {
      // softmax functionality but require normalizing performed later
      for (unsigned int j = 0; j < NN_def[i]; j++) {
        y[j] = AccFunction(i, j);
        // tracking the max index
        if ((j > 0) && (abs(y[maxIndx]) < abs(y[j]))) {
          maxIndx = j;
        }
      }
    } else {
      // for subsequent layers, we need to perform RELU
      for (unsigned int j = 0; j < NN_def[i]; j++) {
        L[i].Neu[j].X = ACT(AccFunction(i, j)); // Equation (21)
      }
      if (isTraining) {
        applyDropout(L[i].Neu, NN_def[i], dropoutRate);
      }
    }
  }

  // performing exp but ensuring we dont exceed 709 or 88 in any terms
  DATA_TYPE norm = abs(y[maxIndx]);
  if (norm > EXP_LIMIT) {
#if DEBUG
    Serial.print("Max limit exceeded for exp:");
    Serial.println(norm);
#endif
    norm = norm / EXP_LIMIT;
#if DEBUG
    Serial.print("New divising factor:");
    Serial.println(norm);
#endif
  } else {
    norm = 1.0;
  }
  for (unsigned int j = 0; j < NN_def[numLayers - 1]; j++) {
    // int flag = 0;
    y[j] = EXP(y[j] / norm);
    Fsum += y[j];
  }

  // final normalizing for softmax
  for (unsigned int j = 0; j < NN_def[numLayers - 1]; j++) {
    y[j] = y[j] / Fsum;
  }
}


const double lambda = 0 /* your regularization strength */;

void backwardProp() {
  for (unsigned int i = numLayers - 1; i > 1; i--) {
    for (unsigned int j = 0; j < NN_def[i]; j++) {
      L[i].Neu[j].dA = dLossCalc(i, j);

      for (int k = 0; k < NN_def[i - 1]; k++) {
        // Original gradient calculation
        double originalGradient = L[i].Neu[j].dA * L[i - 1].Neu[k].X;

        // Add L2 regularization term
        double weight = L[i].Neu[j].W[k]; //  W[k] is the weight
        double l2Term = lambda * weight;

        // Update the gradient with L2 regularization
        L[i].Neu[j].dW[k] = -LEARNING_RATE * (originalGradient + l2Term);

        // Update the weight
        // L[i].Neu[j].W[k] += L[i].Neu[j].dW[k];
      }
      L[i].Neu[j].dB = -LEARNING_RATE * L[i].Neu[j].dA;
    }
  }
}



// function to set the input and output vectors for training or inference
void generateTrainVectors(int indx) {

	// Train Data
	for (unsigned int j = 0; j < OUT_VEC_SIZE; j++) {
		hat_y[j] = 0.0;
	}
	hat_y[ train_labels[ indxArray[indx] ] ] = 1.0;

	for (unsigned int j = 0; j < IN_VEC_SIZE; j++) {
		input[j] = train_data[ indxArray[indx] ][j];
	}

}

void shuffleIndx()
{
  for (unsigned int i = 0; i < train_data_cnt - 1; i++)
  {
    size_t j = i + rand() / (RAND_MAX / (train_data_cnt - i) + 1);
    unsigned int t = indxArray[j];
    indxArray[j] = indxArray[i];
    indxArray[i] = t;
  }
}

int calcTotalWeightsBias()
{
	int Count = 0;
	for (unsigned int i = 0; i < numLayers - 1; i++) {
		Count += NN_def[i] * NN_def[i + 1] + NN_def[i + 1];
	}

	return Count;
}

void printAccuracy()
{
  // checking accuracy if training data
  int correctCount = 0;

  for (unsigned int i = 0; i < numTrainData; i++) {
    int maxIndx = 0;
    for (unsigned int j = 0; j < IN_VEC_SIZE; j++) {
      input[j] = train_data[i][j];
    }

    forwardProp(1);
    for (unsigned int j = 1; j < OUT_VEC_SIZE; j++) {
      if (y[maxIndx] < y[j]) {
        maxIndx = j;
      }
    }
    if (maxIndx == train_labels[i]) {
      correctCount += 1;
    }
  }

  float Accuracy = correctCount * 1.0 / numTrainData;
  Serial.print("Training Accuracy: ");
  Serial.println(Accuracy);

  correctCount = 0;
  for (unsigned int i = 0; i < numValData; i++) {
    int maxIndx = 0;
    for (unsigned int j = 0; j < IN_VEC_SIZE; j++) {
      input[j] = validation_data[i][j];
    }

    forwardProp(0);
    for (unsigned int j = 1; j < OUT_VEC_SIZE; j++) {
      if (y[maxIndx] < y[j]) {
        maxIndx = j;
      }
    }
    if (maxIndx == validation_labels[i]) {
      correctCount += 1;
    }
  }

  Accuracy = correctCount * 1.0 / numValData;
  Serial.print("Validation Accuracy: ");
  Serial.println(Accuracy);

  correctCount = 0;
  for (unsigned int i = 0; i < numTestData; i++) {
    int maxIndx = 0;
    for (unsigned int j = 0; j < IN_VEC_SIZE; j++) {
      input[j] = test_data[i][j];
    }

    forwardProp(0);
    for (unsigned int j = 1; j < OUT_VEC_SIZE; j++) {
      if (y[maxIndx] < y[j]) {
        maxIndx = j;
      }
    }
    if (maxIndx == test_labels[i]) {
      correctCount += 1;
      // Serial.print("Test Sample ");
      // Serial.print(i);
      // Serial.print(": Predicted Class = ");
      // Serial.print(classLabels[maxIndx]); // Use the label from classLabels array
      // Serial.print(", Actual Class = ");
      // Serial.println(classLabels[test_labels[i]]); // Use the label from classLabels array 
    }
    Serial.print("Test Sample ");
    Serial.print(i);
    Serial.print(": Predicted Class = ");
    Serial.print(classLabels[maxIndx]); // Use the label from classLabels array
    Serial.print(", Actual Class = ");
    Serial.println(classLabels[test_labels[i]]); // Use the label from classLabels array 
  }

  Accuracy = correctCount * 1.0 / numTestData;
  Serial.print("Test Accuracy: ");
  Serial.println(Accuracy);
}


#define PACK 0
#define UNPACK 1
#define AVERAGE 2
// 0 -> pack vector for creating vector based on local NN for bluetooth transmission
// 1 -> unpack vector for updating weights on local NN after receiving vector via bluetooth transmission
// 2 -> average between values in pointer and location network values, and update both local NN and pointer value
void packUnpackVector(int Type)
{
  unsigned int ptrCount = 0;
  if (Type == PACK) {
    // Propagating through network, we store all weights first and then bias.
    // we start with left most layer, and top most node or lowest to highest index
    for (unsigned int i = 1; i < numLayers; i++) {
      for (unsigned int j = 0; j < NN_def[i]; j++) {
        for (unsigned int k = 0; k < L[i].Neu[j].numInput; k++) {
          WeightBiasPtr[ptrCount] = L[i].Neu[j].W[k];
          ptrCount += 1;
        }
        WeightBiasPtr[ptrCount] = L[i].Neu[j].B;
        ptrCount += 1;
      }
    }

    //Serial.print("Total count when packing:");
    //Serial.println(ptrCount);

  } else if (Type == UNPACK) {
    // Propagating through network, we store all weights first and then bias.
    // we start with left most layer, and top most node or lowest to highest index
    for (unsigned int i = 1; i < numLayers; i++) {
      for (unsigned int j = 0; j < NN_def[i]; j++) {
        for (unsigned int k = 0; k < L[i].Neu[j].numInput; k++) {
          L[i].Neu[j].W[k] = WeightBiasPtr[ptrCount];
          ptrCount += 1;
        }
        L[i].Neu[j].B = WeightBiasPtr[ptrCount];
        ptrCount += 1;
      }
    }
  } else if (Type == AVERAGE) {
    // Propagating through network, we store all weights first and then bias.
    // we start with left most layer, and top most node or lowest to highest index
    for (unsigned int i = 1; i < numLayers; i++) {
      for (unsigned int j = 0; j < NN_def[i]; j++) {
        for (unsigned int k = 0; k < L[i].Neu[j].numInput; k++) {
          L[i].Neu[j].W[k] = (WeightBiasPtr[ptrCount] + L[i].Neu[j].W[k] ) / 2;
          WeightBiasPtr[ptrCount] = L[i].Neu[j].W[k];
          ptrCount += 1;
        }
        L[i].Neu[j].B = (WeightBiasPtr[ptrCount] + L[i].Neu[j].B ) / 2;
        WeightBiasPtr[ptrCount] = L[i].Neu[j].B;
        ptrCount += 1;
      }
    }
  }
}

// Called from main in setup-function
void setupNN(DATA_TYPE* wbptr) {
  WeightBiasPtr = wbptr;
  createNetwork();
}

void predict(DATA_TYPE image_data[IN_VEC_SIZE]) {
  const char* words[20] = {"the","of","and","a","to","in","is","you","that","it","he","was","for","on","are","as","with","his","they","I"};

  int maxIndx = 0;
  for (unsigned int j = 0; j < IN_VEC_SIZE; j++) {
    input[j] = image_data[j];
  }

  forwardProp(0);
  for (unsigned int j = 1; j < OUT_VEC_SIZE; j++) {
    if (y[maxIndx] < y[j]) {
      maxIndx = j;
    }
  }

  Serial.println("The words is: ");
  Serial.print(words[maxIndx]);
}
